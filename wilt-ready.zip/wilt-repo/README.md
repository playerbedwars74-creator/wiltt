# wilt selfbot

A feature-rich Discord selfbot built on [discord.py-self](https://github.com/dolfies/discord.py-self).

## ⚠️ Disclaimer

Using a selfbot violates Discord's Terms of Service. Use at your own risk.

---

## Setup

### Requirements
- Python 3.11+
- ffmpeg

### Install

```bash
git clone https://github.com/YOUR_USERNAME/wilt.git
cd wilt
pip install -r requirements.txt
```

### Configure

Copy `.env.example` to `.env` and fill it in:

```bash
cp .env.example .env
```

```
TOKEN=your_discord_user_token
PREFIX=.
RPC_APP_ID=1552026905023356938
X_SUPER_PROPERTIES=
CAPTCHA_API_KEY=
CAPTCHA_PROVIDER=2captcha
```

**Getting your token:** Discord → F12 → Network tab → any API request → Request Headers → `Authorization`

> Never share your token or commit your `.env` file.

### Run

```bash
python selfbot.py
```

---

## Deployment (Railway / plugged.host)

The repo includes `nixpacks.toml`, `railpack.json`, and `Procfile` for one-click deploy on Railway or plugged.host.

Set `TOKEN` as an environment variable in the platform dashboard — do **not** commit it.

---

## Cogs

| Cog | Description |
|-----|-------------|
| afk | AFK status with ping logging |
| ai | AI chat integration |
| antid | Anti-delete / sniper |
| auto | Auto-reactions, auto-responses |
| backup | Server backup |
| badge | Badge collection display |
| bumper | Server bumping automation |
| filters | Message filters |
| general | General utilities |
| host | Hosting helpers |
| mass | Mass DM / actions |
| pack | Item/pack system |
| quests | Quest system |
| rpc | Rich Presence control |
| sniper | Message/reaction sniper |
| spoofer | Profile spoofer |
| themes | Theme system |
| voice | Voice utilities |
| ... | and more |

---

## Library Note

**Must use `discord.py-self` — never plain `discord.py`.**

If you get `Improper token` errors after install, delete `site-packages/discord/` and `discord_py_self-*.dist-info`, then reinstall only `discord.py-self`.
